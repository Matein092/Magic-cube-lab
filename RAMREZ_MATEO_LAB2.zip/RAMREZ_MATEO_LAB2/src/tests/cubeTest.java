package tests;

import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import customException.NotParException;
import model.CubeMagic;


class cubeTest {
	
	private CubeMagic cube;
	
	private void setUpScenary1 () {
		cube = new CubeMagic();
	}	
	
	@Test
	public void testCubeNotNull() {
		setUpScenary1();
		int number = 0;
		int m = cube.getSize();
		cube.fillCubeNE();
		int[][] matrix = cube.getCube();
		for(int i = 0; i < matrix.length;i++) {
			for(int j = 0; j < matrix.length;j++) {
				if(matrix[i][j] != 0) {
				number++;
				}
			}
		}
		
		assertTrue("If size * size is the same of the numbers not 0", (m * m) == number );
	}
	@Test
	public void testIfMagic() {
		setUpScenary1();
		int f = 0;
		int k = 0;
		cube.fillCubeSE();
		int[][] matrix = cube.getCube();
		for(int i = 0; i < matrix.length;i++) {
			for(int j = 0; j < matrix.length;j++) {
				while(i == 0) {
					k += matrix[i][j];
				}
					f += matrix[i][j];
				}
		}
		assertTrue("If all the sume rows are the same", (f / matrix.length) == k);
		
	}
	
	@Test
	public void testNumberPar() throws NotParException{
		  setUpScenary1();
		  cube.setSize(10);	
		  fail("Se esperaba excepcion NotParException");
		}	
	
	
}