package model;

import customException.NotParException;

public class CubeMagic {
	
	 private int size;
	 private int[][] cube;
	 
	 public CubeMagic() {
		 try {
			findSize();
		} catch (NotParException excep) {
			excep.printStackTrace();
		}
	 }
	 
	 public int[][] getCube() {
		 return cube;
	 }
	 
	 public void setCube(int[][] cube) {
		 this.cube = cube;
	 }
	 
	 public int getSize() {
		 return size;
	 } 	
	 
	 public void setSize(int size) {
		 this.size = size;
	 }
	 
	 public void findSize() throws NotParException  {
		 int n = 0;
		try {
			 do{
				 n = (int) (Math.random()*9) + 1;
			 }
			 while((n % 2) == 0);
			 size = n;
			 cube = new int[size][size];
		}
		catch(ArithmeticException parException) {
			throw new NotParException();
		}
	 }
		 
	 
	 public void fillCubeSE() {
		 int row_previous = 0;
		 int column_previous = 0;
		 int punt_ini = size/2;
		 int temp = 1;
		 for(int i = 0; i < size; i++) {
			 for(int j = 0; j < size; j++) {
			 cube[i][j] = 0;
			 }
		 }
		 int x = 0;
		 int j = punt_ini;
		 while(temp != (size*size) + 1){
			 if(cube[x][j] == 0) {
				 cube[x][j] = temp;
			 }else {
				 x = row_previous + 1;
				 j = column_previous;
				 cube[x][j] = temp;
			 }
			 row_previous = x;
			 column_previous = j;
			 temp++;
			 j++;
			 x--;
			 if(x < 0 && j == size) {
				 x = size - 1;
				 j = 0;
			 }else if(x < 0) {
				 x = x + size;
			 }else if(j == size) {
				 j = 0;
			 }
				 
			 }
		 }
	 public void fillCubeSO() {
		 int row_previous = 0;
		 int column_previous = 0;
		 int punt_ini = size/2;
		 int temp = 1;
		 for(int i = 0; i < size; i++) {
			 for(int j = 0; j < size; j++) {
			 cube[i][j] = 0;
			 }
		 }
		 int x = 0;
		 int j = punt_ini;
		 while(temp != (size*size) + 1){
			 if(cube[x][j] == 0) {
				 cube[x][j] = temp;
			 }else {
				 x = row_previous - 1;
				 j = column_previous;
				 cube[x][j] = temp;
			 }
			 row_previous = x;
			 column_previous = j;
			 temp++;
			 j++;
			 x--;
			 if(x < 0 && j == size) {
				 x = size - 1;
				 j = 0;
			 }else if(x < 0) {
				 x = x + size;
			 }else if(j == size) {
				 j = 0;
			 }
				 
			 }
		 }
	 public void fillCubeNO() {
		 int row_previous = 0;
		 int column_previous = 0;
		 int punt_ini = size/2;
		 int temp = 1;
		 for(int i = 0; i < size; i++) {
			 for(int j = 0; j < size; j++) {
			 cube[i][j] = 0;
			 }
		 }
		 int x = 0;
		 int j = punt_ini;
		 while(temp != (size*size) + 1){
			 if(cube[x][j] == 0) {
				 cube[x][j] = temp;
			 }else {
				 x = row_previous - 1;
				 j = column_previous;
				 cube[x][j] = temp;
			 }
			 row_previous = x;
			 column_previous = j;
			 temp++;
			 j++;
			 x--;
			 if(x < 0 && j == size) {
				 x = size - 1;
				 j = 0;
			 }else if(x < 0) {
				 x = x + size;
			 }else if(j == size) {
				 j = 0;
			 }
				 
			 }
		 }
	 public void fillCubeNE() {
		 int row_previous = 0;
		 int column_previous = 0;
		 int punt_ini = size/2;
		 int temp = 1;
		 for(int i = 0; i < size; i++) {
			 for(int j = 0; j < size; j++) {
			 cube[i][j] = 0;
			 }
		 }
		 int x = 0;
		 int j = punt_ini;
		 while(temp != (size*size) + 1){
			 if(cube[x][j] == 0) {
				 cube[x][j] = temp;
			 }else {
				 x = row_previous + 1 ;
				 j = column_previous ;
				 cube[x][j] = temp;
			 }
			 row_previous = x;
			 column_previous = j;
			 temp++;
			 j++;
			 x--;
			 if(x < 0 && j == size) {
				 x = size - 1;
				 j = 0;
			 }else if(x < 0) {
				 x = x + size;
			 }else if(j == size) {
				 j = 0;
			 }
				 
			 }
		 }
}
