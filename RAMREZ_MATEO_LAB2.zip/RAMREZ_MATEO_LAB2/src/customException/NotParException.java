package customException;

public class NotParException extends Exception {
	
	public NotParException() {
		super("The number is par");
	}

}
