package userInterface;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import model.CubeMagic;


public class Controller {
	
	@FXML
    private Label magic;

    @FXML
    private GridPane pane;
    
    private CubeMagic cube;
	
    public void playGame(ActionEvent event) {
    	System.out.println("Jugando...");
    	pane.setGridLinesVisible(true);
    	cube.fillCubeSE();
    	for(int i = 0; i < cube.getCube().length;i++) {
    		for(int j = 0; j < cube.getCube().length;j++) {
    			String txtT = Integer.toString(cube.getCube()[i][j] );
    			pane.add(new Label(txtT), i, j);
    		}
    	}
    }
    	
    public void playGame2(ActionEvent event) {
    	System.out.println("Jugando...");
    	pane.setGridLinesVisible(true);
    	cube.fillCubeSO();
    	for(int i = 0; i < cube.getCube().length;i++) {
    		for(int j = 0; j < cube.getCube().length;j++) {
    			String txtT = Integer.toString(cube.getCube()[i][j] );
    			pane.add(new Label(txtT), i, j);
    		}
    	}
    }
    
    public void playGame3(ActionEvent event) {
    	System.out.println(cube.getSize());
    	System.out.println("Jugando...");
    	pane.setGridLinesVisible(true);
    	cube.fillCubeNO();
    	for(int i = 0; i < cube.getCube().length;i++) {
    		for(int j = 0; j < cube.getCube().length;j++) {
    			String txtT = Integer.toString(cube.getCube()[i][j] );
    			pane.add(new Label(txtT), i, j);
    		}
    	}
    }
    public void playGame4(ActionEvent event) {
    	System.out.println(cube.getSize());
    	System.out.println("Jugando...");
    	pane.setGridLinesVisible(true);
    	cube.fillCubeNE();
    	for(int i = 0; i < cube.getCube().length;i++) {
    		for(int j = 0; j < cube.getCube().length;j++) {
    			String txtT = Integer.toString(cube.getCube()[i][j] );
    			pane.add(new Label(txtT), i, j);
    		}
    	}
    }
    
    
    	

    public void cleanGame(ActionEvent event){
    	pane.getChildren().clear();
    }
	
    @FXML
    public void initialize() {
    	cube = new CubeMagic();
    }

}
